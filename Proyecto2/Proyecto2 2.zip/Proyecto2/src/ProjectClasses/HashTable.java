/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProjectClasses;

/**
 *
 * @author juanmendezl
 */
public class HashTable<K, V> {
    private SimpleList<Entry<K, V>>[] array;
    private int size;
    
    private static class Entry<K, V> {
        K key;
        V value;
        Entry<K, V> next;
        
        Entry(K key, V value){
            this.key = key;
            this.value= value;
            this.next = null;
        }
    }
    
    /**
     * consturctor del Has
     * @param root raiz del arbol
     **/

    public HashTable(int size) {
        this.size = size;
        array = new SimpleList[size];
        for (int i = 0; i < 10; i++) {
            array[i] = new SimpleList<>();
        }
    }
    
      /**
     * este metodo retorna el hashcode del key ingresado por parametro
     * @param key elemento a buscar
     * @return int
     **/
    
    private int getHash(K key){
        int hashCode = key.hashCode();
        return Math.abs(hashCode) % size;
    }
    
    /**
     * este metodo ingresa un key y un value
     * @param key llave a ingresar
     * @param value valor del key ingresado
     **/
    
    public void put(K key, V value){
        int index = getHash(key);
        if (array[index] == null){
            array[index] = new SimpleList<>();
        }
        SimpleList<Entry<K, V>> list = array[index];
        NodoLista<Entry<K, V>> node = list.getHead();
        while(node != null){
            Entry<K, V> entry = node.getData();
            if (entry.key.equals(key)){
                entry.value = value;
                return;
            }
            node = node.getPnext();
        }
        list.add(new Entry<>(key, value));
    }
    
    /**
     * este metodo ingresa un key
     * @param key llave a buscar value
     * @return V del key 
     **/
    
    public V get(K key){
        int index = getHash(key);
        if (array[index] == null){
            return null;
        }
        SimpleList<Entry<K, V>> list = array[index];
        NodoLista<Entry<K, V>> node = list.getHead();
        while(node != null) {
            Entry<K, V> entry = node.getData();
            if(entry.key.equals(key)) {
                return entry.value;
            }
            node = node.getPnext();
        }
        return null;
    }
    
    /**
     * este metodo remueve el key ingresa por parametro
     * @param key llave a remover
     **/
    
    public void remove(K key){
        int index = getHash(key);
        
        if (array[index] == null){
            return;
        }
        SimpleList<Entry<K, V>> list = array[index];
        NodoLista<Entry<K, V>> node = list.getHead();
        NodoLista<Entry<K, V>> prev = null;
        
        while (node != null){
            Entry<K, V> entry = node.getData();
            if (entry.key.equals(key)){
                if (prev == null){
                    list.setHead(node.getPnext());
                } else {
                    prev.setPnext(node.getPnext());
                }
                return;
            }
            prev = node;
            node = node.getPnext();
        }
    }
    
    /**
     * este metodo ingresa un key por parametro y remplaza el valor por uno nuevo
     * @param key llave a buscar
     * @param replace valor que va a ser el remplazo
     **/
    
    public void replaceValue(K key,String replace){
        V value = get(key);
        this.remove(key);
        this.put(key,(V)replace);     
    }
    
    /**
     * este metodo ingresa un value por parametro y retorna la habitacion relacionada
     * @param value a buscar
     * @return habitacion a encontrar
     **/
    
    public K getHab(V value){
        int i = 0;
        while(i < this.size){
            NodoLista<Entry<K, V>> aux = array[i].getHead();
            while(aux != null) {
                if(aux.getData().value.equals(value)){
                    return aux.getData().key;    
                }
                aux = aux.getPnext();
            i++;
            }
        }
        return null;
    }
}
